$(document).ready(function  () {
  $('#fuentes').hide();
  $('.border').on('click', function  () {
    $('#inicio').hide();
    $('#fuentes').show();
  });
})
